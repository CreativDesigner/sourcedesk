<?php
/*
Plugin Name: sourceDESK
Plugin URI:  https://sourceway.de/sourcedesk
Description: Dieses Plugin integriert sourceDESK in WordPress und stellt Informationen aus sourceDESK mittels diverser Shortcodes bereit.
Version:     1.0.0
Author:      sourceWAY
Author URI:  https://sourceway.de
*/

defined('ABSPATH') or die('Direct file access is not permitted');

class sourcedesk {
    private $products;

    public function __construct() {
        // Plugin settings
        register_setting("sourcedesk", "url");
        register_setting("sourcedesk", "key");

        // Admin options page
        if (is_admin()) {
            add_filter( 'plugin_action_links_' . plugin_basename(__FILE__), array($this, 'plugin_action_links'));
            add_action('admin_menu', array($this, 'admin_menu'));
        }

		// Shortcodes
		add_shortcode("sourcedesk_product", array($this, "product"));
		add_shortcode("sourcedesk", array($this, "sourcedesk"));
    }

    // Admin menu hook
    public function admin_menu() {
        add_options_page("Einstellungen &rsaquo; sourceDESK", "sourceDESK", "manage_options", "sourcedesk", array($this, "options"));
    }

    // Plugin action link hook
    public function plugin_action_links($links) {
        return array_merge(array('<a href="'. esc_url(get_admin_url(null, 'options-general.php?page=sourcedesk') ) .'">Einstellungen</a>'), $links);
    }

    // Options page
    public function options() {
        echo '<div class="wrap"><h1>Einstellungen &rsaquo; sourceDESK</h1>';
        echo '<form method="post" action="options.php">';
        echo '<table class="form-table">';

        settings_fields('sourcedesk');
        do_settings_sections('sourcedesk');

        echo '<tr valign="top">';
        echo '<th scope="row">sourceDESK-URL (mit abschließendem Slash)</th>';
        echo '<td><input type="text" name="url" value="' . esc_attr(get_option('url')) . '" /></td>';
        echo '</tr>';

        echo '<tr valign="top">';
        echo '<th scope="row">WordPress-Schl&uuml;ssel</th>';
        echo '<td><input type="text" name="key" value="' . esc_attr(get_option('key')) . '" /></td>';
        echo '</tr>';

        echo '</table>';

		$status = '<font color="red"><b>Verbindung fehlgeschlagen</b></font>';
		if (!empty(get_option('url'))) {
			$ch = curl_init(get_option('url') . "/wordpress_bridge/" . get_option('key') . "/hw");
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
			curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
			$res = curl_exec($ch);
			curl_close($ch);

			if ($res && is_array($res = json_decode($res, true))) {
				if (isset($res['error'])) {
					$status = '<font color="red"><b>' . htmlentities($res['error']) . '</b></font>';
				} else if (isset($res['msg']) && $res['msg'] == "Hello World!") {
					$status = '<font color="green"><b>Verbindung erfolgreich</b></font>';
				}
			}
		}

		echo $status;

        submit_button();
        echo '</form>';
        echo '</div>';
    }

    // Get products from server
    public function fetchProducts() {
		$ch = curl_init(get_option('url') . "/wordpress_bridge/" . get_option('key') . "/products");
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
		$res = curl_exec($ch);
		curl_close($ch);

		if (!$res || !@is_array($res = json_decode($res, true))) {
			return "Invalid server answer";
		}

		if (isset($res['error'])) {
			return $res['error'];
		}

		$this->products = $res;
		return true;
    }

    // Product details
    public function product($pars) {
		$pid = $pars[0];
		if (!is_numeric($pid) || $pid <= 0) {
			return "Product ID invalid";
		}

		$key = $pars[1];
		if (empty($key)) {
			return "No option specified";
		}

		if (!$this->products && true !== ($res = $this->fetchProducts())) {
			return $res;
		}

		if (!array_key_exists($pid, $this->products)) {
			return "Product not found";
		}

		$p = $this->products[$pid];
		if (!array_key_exists($key, $p)) {
			return "Invalid option \"$key\"";
		}

		return $p[$key];
    }

    // Include sourceDESK
    public function sourcedesk($pars) {
		$page = "";
		if (!empty($pars[0])) {
			$page = $pars[0];
		}

		return '<script type="text/javascript" src="' . plugins_url() . '/sourcedesk/iframeResizer.js"></script><style>iframe{width: 1px;min-width: 100%;}</style><iframe onload="iFrameResize({log: true}, \'#sourcedeskFrame\')" id="sourcedeskFrame" src="' . get_option("url") . $page . '" scrolling="no" style="border: none;"></iframe>';
    }
}

new sourcedesk;