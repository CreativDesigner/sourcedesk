<?php
use \Illuminate\Database\Capsule\Manager as Capsule;

function sw_domainimport_config() {
    $configarray = array(
        "name" => "sourceWAY Import",
		"description" => "Mit diesem Addon k&ouml;nnen Sie die Domain-Preise von sourceWAY.de automatisch importieren.",
        "version" => "1.0",
        "author" => "<a href=\"https://sourceway.de/\" target=\"_blank\">sourceWAY.de</a>",
        "language" => "german",
        "premium" => "yes",
        "fields" => array(),
    );
	
    return $configarray;
}

function sw_domainimport_activate() {
	return Array("status" => "success", "description" => "Das Modul wurde erfolgreich aktiviert. Bitte setzen Sie nun die Zugriffsrechte.");
}

function sw_domainimport_deactivate() {
	return Array("status" => "success", "description" => "Das Modul wurde erfolgreich deaktiviert.");
}

function sw_domainimport_output($settings) {
	if(isset($_FILES['file'])){
		$lines = explode("\n", file_get_contents($_FILES['file']['tmp_name']));
		array_shift($lines);
		$fields = Array(
			"12" => "msetupfee",
			"24" => "qsetupfee",
			"36" => "ssetupfee",
			"48" => "asetupfee",
			"60" => "bsetupfee",
			"72" => "monthly",
			"84" => "quarterly",
			"96" => "semiannually",
			"108" => "annually",
			"120" => "biennially",
		);
		
		foreach($lines as $i => $line){
			$cols = explode(";", $line);
			foreach($cols as &$col)
				$col = trim(trim(ltrim($col, "="), '"'));

			$tld = "." . $cols[0];
			$create = doubleval($cols[1]);
			$transfer = doubleval($cols[2]);
			$renew = doubleval($cols[3]);
			$field = $fields[intval($cols[5]) * 12];
			if(empty($field)) $field = $fields[12];

			$sql = Capsule::table("tbldomainpricing")->where("extension", $tld);
			if($sql->count() == 1){
				$id = $sql->get()[0]->id;
				Capsule::table("tbldomainpricing")->where("extension", $tld)->update(Array("dnsmanagement" => "on", "eppcode" => "on", "autoreg" => "sourceway"));
				Capsule::table('tblpricing')->where("relid", $id)->where("type", "LIKE", 'domain%')->where("tsetupfee", $_POST['clientgroup'])->delete();
			} else {
				$id = Capsule::table('tbldomainpricing')->insertGetId(Array(
					"extension" => $tld,
					"dnsmanagement" => "on",
					"eppcode" => "on",
					"autoreg" => "autodns",
				));
			}

			$createp = Array($field => $create);
			$transferp = Array($field => $transfer);
			$renewp = Array($field => $renew);

			foreach($fields as $f)
				if($f != $field)
					$createp[$f] = $transferp[$f] = $renewp[$f] = -1;
					
			Capsule::table('tblpricing')->insert(Array(
				array_merge(Array("type" => "domainregister", "currency" => "1", "relid" => $id, "tsetupfee" => $_POST['clientgroup']), $createp),
				array_merge(Array("type" => "domaintransfer", "currency" => "1", "relid" => $id, "tsetupfee" => $_POST['clientgroup']), $transferp),
				array_merge(Array("type" => "domainrenew", "currency" => "1", "relid" => $id, "tsetupfee" => $_POST['clientgroup']), $renewp),
			));
		}

		echo "<font color='green'><b>Die Preise wurden erfolgreich importiert!</b></font>";
	}
	?>

	<p align="justify">Hier k&ouml;nnen Sie Ihre Preisliste von sourceWAY.de importieren. Dazu laden Sie die Preisliste als CSV herunter. Dies geht in der <a href="https://sourceway.de/de/domains/api" target="_blank">API-Ansicht</a>, sofern diese aktiviert ist.</p>

	<p align="justify">Jegliche &Auml;nderungen an den Preisen sollten Sie vorher mit einem Text-Editor in der CSV vornehmen (Preisaufschlag f&uuml;r Ihre Kunden). Sie k&ouml;nnen die Kundengruppe ausw&auml;hlen, f&uuml;r die die Preise gelten sollen. Existiert eine Domain-Endung bereits, werden die Preise f&uuml;r die jeweilige Kundengruppe durch die neuen Preise &uuml;berschrieben. Die Domain-Endung wird automatisch dem Registrar-Modul f&uuml;r sourceWAY zugeordnet. Alle Preise gelten f&uuml;r die Standard-W&auml;hrung.</p>
	
	<form method="POST" enctype="multipart/form-data">
		<select name="clientgroup" class="form-control" style="margin-bottom: 10px;">
			<option value="0" selected="selected">- Standardpreise -</option>
			<?php
			$sql = Capsule::table('tblclientgroups')->orderBy('groupname', 'ASC')->get();
			foreach($sql as $row)
				echo '<option value="' . $row->id . '">' . $row->groupname . '</option>';
			?>
		</select>

		<input type="file" name="file" class="form-control" style="margin-bottom: 10px;" />

		<center><input type="submit" class="btn btn-block btn-primary" value="Preise importieren"></center>
	</form>
	<?php		
}

?>