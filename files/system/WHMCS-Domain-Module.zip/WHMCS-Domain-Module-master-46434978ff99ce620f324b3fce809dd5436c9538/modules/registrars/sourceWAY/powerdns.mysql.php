<?php

class PowerDNS_MySQL {
	protected $mail = "mail.sourceway.de";
	protected $link;

	public function connect($hst, $usr, $pwd, $dbn) {
		$this->link = new MySQLi($hst, $usr, $pwd, $dbn);
		if(!$this->link || $this->link->connect_errno) return false;
		return true;
	}

	public function add($domain, Array $ns) {
		if(count($ns) < 2) return false;
		$soa = "{$ns[0]} {$this->mail} " . date("Ymd") . "01 28800 7200 604800 86400";
		
		$this->link->query("INSERT INTO domains (`name`, `type`) VALUES ('$domain', 'MASTER')");
		$obj = new PowerDNS_Domain($this->link->insert_id, $this->link);
		$obj->add("", "SOA", $soa);
		
		foreach($ns as $s)
			$obj->add("", "NS", $s);
		return $obj;
	}

	public function get($domain) {
		$sql = $this->link->query("SELECT id FROM domains WHERE name = '$domain'");
		if($sql->num_rows == 1) return new PowerDNS_Domain($sql->fetch_object()->id, $this->link);
		return false;
	}

	public function mail($mail) {
		$this->mail = str_replace("@", ".", $mail);
	}
}

class PowerDNS_Domain {
	protected $id;
	protected $link;
	protected $name;

	public function __construct($id, $link) {
		$this->id = $id;
		$this->link = $link;

		$sql = $this->link->query("SELECT name FROM domains WHERE id = " . $id);
		if($sql->num_rows == 1) $this->name = $sql->fetch_object()->name;
	}

	public function add($subdomain, $type, $content = "", $priority = 0, $ttl = 180) {
		if(!empty($subdomain)) $subdomain = rtrim($subdomain, ".");

		if($subdomain == $this->name)
			$subdomain = "";
		if(substr($subdomain, strlen($this->name) / -1) == $this->name);
			$subdomain = substr($subdomain, 0, strlen($this->name) / -1);
		$subdomain = trim($subdomain, ".");

		$domain = $subdomain . (!empty($subdomain) ? "." : "") . $this->name;

		return (bool) $this->link->query("INSERT INTO records (`domain_id`, `name`, `type`, `content`, `ttl`, `prio`, `change_date`) VALUES ({$this->id}, '$domain', '$type', '$content', $ttl, $priority, " . time() . ")");
	}

	public function def($ip) {
		$this->add("", "A", $ip);
		$this->add("*", "A", $ip);
		$this->add("", "MX", $this->name);
	}

	public function get() {
		$records = Array();
	    $sql = $this->link->query("SELECT * FROM records WHERE domain_id = {$this->id}");
	    while($item = $sql->fetch_object())
	        if($item->type != "NS" && $item->type != "SOA")
	            array_push($records, Array("hostname" => $item->name, "type" => $item->type, "address" => $item->content, "priority" => $item->prio));
	    return $records;
	}

	public function replace($records) {
		$this->link->query("DELETE FROM records WHERE domain_id = {$this->id} AND type != 'SOA' AND type != 'NS'");

	    foreach ($records AS $r) {
	        while(substr($r['hostname'], -1) == ".")
	            $r['hostname'] = substr($r['hostname'], 0, -1);

	        if(empty($r['hostname']) || $r['hostname'] == "." . $this->name || ($r['hostname'] != $this->name && substr($r['hostname'], strlen($this->name) / -1 - 1) != "." . $this->name))
	            continue;

	        if(empty($r['address'])) continue;
	        if($r['type'] == "MX" && (!isset($r['priority']) || !is_numeric($r['priority']))) $r['priority'] = "10";
			if(empty($r['ttl'])) $r['ttl'] = "86400";
	        $r['priority'] = intval($r['priority']);
	        
	        $this->add($r['hostname'], $r['type'], $r['address'], $r['priority'], $r['ttl']);
	    }
	}
}