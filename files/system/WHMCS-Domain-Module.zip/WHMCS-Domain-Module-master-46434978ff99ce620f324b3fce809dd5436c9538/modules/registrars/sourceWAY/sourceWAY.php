<?php
use \Illuminate\Database\Capsule\Manager as Capsule;

function sourceWAY_getConfigArray() {
	$status = "<font color='red'>Verbindung fehlgeschlagen</font>";
	$user = $key = "";

	$sql = Capsule::table('tblregistrars')->where("registrar", "sourceway")->get();
	foreach($sql as $row){
		if($row->setting == "user") $user = decrypt($row->value);
		if($row->setting == "api_key") $key = decrypt($row->value);
	}

	$res = file_get_contents("https://sourceway.de/api/$user/$key");
	if($res !== false){
		$json = json_decode($res);
		if(!isset($json->code) || $json->code != "801") $status = "<font color='red'>Authentifizierung fehlgeschlagen</font>";
		else $status = "<font color='green'>Authentifizierung erfolgreich</font>";
	}

	$configarray = array(
		"<b>Zugangsdaten</b>" => array( "Description" => "Bitte geben Sie hier Ihre API-Zugangsdaten ein. Sie finden diese <a href='https://sourceway.de/domains/api' target='_blank'>in den Schnittstellen-Einstellungen</a>.", ),
		"user" => array( "FriendlyName" => "Benutzer-ID", "Type" => "text", "Size" => "20", "Description" => "Ihre Benutzer-ID", ),
		"api_key" => array( "FriendlyName" => "API-Schl&uuml;ssel", "Type" => "text", "Size" => "20", "Description" => "Ihr API-Schl&uuml;ssel", ),
		"Status" => array( "Description" => "<b>$status</b>", ),
		"" => array( "Description" => "&nbsp;", ),
		"<b>Standard-Handle</b>" => array( "Description" => "Bitte geben Sie hier die Daten ein, die standardm&auml;&szlig;ig f&uuml;r Tech-C und Zone-C verwendet werden sollen.", ),
		"Freischaltung" => array( "Description" => "Die Verwendung Ihrer eigenen Daten erfordert gegebenenfalls eine gesonderte Freischaltung durch <a href='https://sourceway.de/contact' target='_blank'>sourceWAY.de</a>.", ),
		"Vorname" => array( "Type" => "text", "Size" => "20" ),
		"Nachname" => array( "Type" => "text", "Size" => "20" ),
		"Firma" => array( "Type" => "text", "Size" => "20", "Description" => "Optional" ),
		"Anschrift" => array( "Type" => "text", "Size" => "20" ),
		"Postleitzahl" => array( "Type" => "text", "Size" => "5" ),
		"Ort" => array( "Type" => "text", "Size" => "20" ),
		"Land" => array( "Type" => "text", "Size" => "5", "Default" => "DE", "Description" => "Zweistelliger L&auml;ndercode" ),
		"Telefon" => array( "Type" => "text", "Size" => "20", "Description" => "Format: +49.0123456789" ),
		"Telefax" => array( "Type" => "text", "Size" => "20", "Description" => "Format: +49.0123456789" ),
		"E-Mailadresse" => array( "Type" => "text", "Size" => "20" ),
		"x" => array( "FriendlyName" => " ", "Description" => "&nbsp;", ),
		"<b>Einstellungen</b>" => array( "Description" => "Nehmen Sie weitere Einstellungen f&uuml;r das Modul bitte hier vor.", ),
		"IP-Adresse" => array( "Type" => "text", "Size" => "20", "Description" => "Eine IPv4-Adresse, die verwendet wird, wenn keine andere ermittelt werden konnte" ),
		"cust_techzone" => array( "FriendlyName" => "Handle-&Auml;nderung", "Type" => "yesno", "Description" => "Kunden d&uuml;rfen Tech-C und Zone-C &auml;ndern (ansonsten nur Administratoren)" ),
		"xy" => array( "FriendlyName" => " ", "Description" => "&nbsp;", ),
		"<b>Nameserver</b>" => array( "Description" => "Bitte tragen Sie diese Nameserver in WHMCS als Standard-Nameserver ein. Nur dann k&ouml;nnen Sie die integrierte DNS-Verwaltung f&uuml;r Domains nutzen.", ),
		"Virtuelle Nameserver" => array( "Description" => "Virtuelle Nameserver sind <a href='https://sourceway.de/contact' target='_blank'>auf Anfrage</a> kostenpflichtig m&ouml;glich.", ),
		"Eigene Nameserver" => array( "Description" => "Die Umschreibung der DNS-Verwaltung zur Verwendung eigener Nameserver (z.B. mit MySQL-Backend) ist <a href='https://sourceway.de/contact' target='_blank'>auf Anfrage</a> kostenpflichtig m&ouml;glich.", ),
		"1. Nameserver" => array( "Description" => "ns1.sourceway.de" ),
		"2. Nameserver" => array( "Description" => "ns2.sourceway.de" ),
		"PowerDNS" => array("Descrption" => "(optional) Host;Benutzername;Passwort;Datenbank;SOA-Mail", "Type" => "text", "Size" => "25"),
	);
	return $configarray;
}

function sourceWAY_getIP($params) {
	$domain = !empty($params['domain']) ? $params['domain'] : $params['domainname'];
	$sql = Capsule::table("tblhosting")->where("domain", $domain);
	if($sql->count() > 0){
		$i = $sql->get()[0];
		if(!empty($i->dedicatedip)) return $i->dedicatedip;

		if(!empty($i->server)){
			$sql = Capsule::table("tblservers")->where("id", $i->server);
			if($sql->count() == 1) return $sql->get()[0]->ipaddress;
		}
	}

	return $params['IP-Adresse'];
}

function sourceWAY_GetNameservers($params) {
	$res = file_get_contents("https://sourceway.de/api/{$params['user']}/{$params['api_key']}/domain/list?domain=" . urlencode($params['domainname']));
	$json = json_decode($res);

	if(!$res || !$json || $json->code != "100")
		return Array("error" => "Es ist ein technischer Fehler aufgetreten.");

	foreach($json->data as $d){
		if($d->domain != $params['domainname']) continue;

		$params = Array();

		$ns = Array();
		for($i = 1; $i <= 5; $i++)
			if(!empty($d->ns[$i - 1]))
				$ns["ns" . $i] = $d->ns[$i - 1];

		return $ns;
	}

	return Array("error" => "Die Domain ist bei sourceWAY.de nicht vorhanden.");
}

function sourceWAY_SaveNameservers($params) {
	$res = file_get_contents("https://sourceway.de/api/{$params['user']}/{$params['api_key']}/domain/list?domain=" . urlencode($params['domainname']));
	$json = json_decode($res);

	if(!$res || !$json || $json->code != "100")
		return Array("error" => "Es ist ein technischer Fehler aufgetreten.");

	foreach($json->data as $d){
		if($d->domain != $params['domainname']) continue;

		$data = Array("domain" => $params['domainname']);

		foreach(Array("owner", "admin", "tech", "zone") as $h)
			foreach($d->$h as $k => $v)
				$data[$h . "_" . $k] = $v;

		for($i = 1; $i <= 5; $i++)
			if(!empty($params["ns" . $i]))
				$data["ns" . $i] = $params["ns" . $i];

		$data['transfer_lock'] = $d->transfer_lock;
		$data['auto_renew'] = $d->auto_renew;
		$data['ip'] = sourceWAY_getIP($params);
		$data['privacy'] = $params['idprotection'] ? "1" : "0";

		$ch = curl_init("https://sourceway.de/api/{$params['user']}/{$params['api_key']}/domain/modify");
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($ch, CURLOPT_POST, true);
		curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data));
		$res = curl_exec($ch);
		curl_close($ch);

		if(json_decode($res)->code != "100") return Array("error" => "Die Nameserver konnten nicht &uuml;bernommen werden. Eventuell existieren Sie nicht oder sind inkonsistent.");
		return true;
	}

	return Array("error" => "Die Domain ist bei sourceWAY.de nicht vorhanden.");
}

function sourceWAY_dns($params) {
	$ex = explode(";", $params["PowerDNS"]);
	if(count($ex) != 5) return false;

	if(!class_exists("PowerDNS_MySQL")) require_once __DIR__ . "/powerdns.mysql.php";
	$dns = new PowerDNS_MySQL;
	if(!$dns->connect($ex[0], $ex[1], $ex[2], $ex[3])) return false;
	$dns->mail($ex[4]);
	return $dns;
}

function sourceWAY_GetDNS($params) {
	if(!empty($params['PowerDNS'])){
		$obj = sourceWAY_dns($params);
		if(!$obj) return Array("error" => "Verbindung zum DNS-Server fehlgeschlagen.");
		
		$domain = isset($params["original"]["domainObj"]) ? ($params["original"]["domainObj"]->getIdnSecondLevel() . $params["original"]["domainObj"]->getDotTopLevel()) : $params['domainname'];
		if(!($d = $obj->get($domain))){
			$ns = Array();
			for($i = 1; $i <= 5; $i++)
				if(!empty($params["ns" . $i]))
					array_push($ns, $params["ns" . $i]);

			$d = $obj->add($domain, $ns);
			$obj->def($params['IP-Adresse']);
		}

		return $d->get();
	}

	$res = file_get_contents("https://sourceway.de/api/{$params['user']}/{$params['api_key']}/dns/list?domain=" . urlencode($params['domainname']));
	$json = json_decode($res);

	if(!$res || !$json || $json->code != "100")
		return Array("error" => "Es ist ein technischer Fehler aufgetreten.");

	foreach($json->data as $d){
		if($d != $params['domainname']) continue;

		$res = file_get_contents("https://sourceway.de/api/{$params['user']}/{$params['api_key']}/dns/show?domain=" . urlencode($params['domainname']));
		$json = json_decode($res);

		if(!$res || !$json || $json->code != "100")
			return Array("error" => "Es ist ein technischer Fehler aufgetreten.");

		$records = Array();
		foreach($json->data as $i => $r)
			array_push($records, Array("recid" => $i, "hostname" => $r->name, "type" => $r->type, "address" => $r->content, "priority" => $r->priority));
		return $records;
	}

	return Array("error" => "Die Domain ist in unserem DNS nicht vorhanden. Werden vielleicht externe Nameserver verwendet?");
}

function sourceWAY_SaveDNS($params) {
	if(!empty($params['PowerDNS'])){
		$obj = sourceWAY_dns($params);
		if(!$obj) return Array("error" => "Verbindung zum DNS-Server fehlgeschlagen.");
		
		$domain = isset($params["original"]["domainObj"]) ? ($params["original"]["domainObj"]->getIdnSecondLevel() . $params["original"]["domainObj"]->getDotTopLevel()) : $params['domainname'];
		if(!($d = $obj->get($domain))) return false;
		$d->replace($params['dnsrecords']);
		return true;
	}

	$err = 0;
    foreach($params['dnsrecords'] as $r){
    	if(!empty($r['recid']) && $r['recid'] > 0){
    		if(!empty($r['address'])){
    			$ch = curl_init("https://sourceway.de/api/{$params['user']}/{$params['api_key']}/dns/edit");
    			curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    			curl_setopt($ch, CURLOPT_POST, true);
    			curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query(Array(
    				"domain" => $params['domainname'],
    				"record" => $r['recid'],
    				"name" => $r['hostname'],
    				"type" => $r['type'],
    				"content" => $r['address'],
    				"priority" => $r['priority'],
    				"ttl" => 3600,
    			)));
    			$res = curl_exec($ch);
    			curl_close($ch);

    			if(json_decode($res)->code != "100") $err = 1;
    		} else {
    			$res = file_get_contents("https://sourceway.de/api/{$params['user']}/{$params['api_key']}/dns/delete?domain=" . urlencode($params['domainname']) . "&record=" . intval($r['recid']));
    			if(json_decode($res)->code != "100") $err = 1;
    		}
    	} else if(!empty($r['address'])) {
    		$ch = curl_init("https://sourceway.de/api/{$params['user']}/{$params['api_key']}/dns/add");
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
			curl_setopt($ch, CURLOPT_POST, true);
			curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query(Array(
				"domain" => $params['domainname'],
				"name" => $r['hostname'],
				"type" => $r['type'],
				"content" => $r['address'],
				"priority" => $r['priority'],
				"ttl" => 3600,
			)));
			$res = curl_exec($ch);
			curl_close($ch);

			if(json_decode($res)->code != "100") $err = 1;
    	}
    }

    if($err) return Array("error" => "Anscheinend ist ein Fehler aufgetreten. Bitte pr&uuml;fen Sie, ob wirklich alle &Auml;nderungen korrekt &uuml;bernommen wurden.");
    return true;
}

function sourceWAY_RegisterDomain($params) {
	$data = Array("domain" => $params['domainname']);

	foreach(Array("owner", "admin") as $h){
		$data[$h . "_firstname"] = $params['firstname'];
		$data[$h . "_lastname"] = $params['lastname'];
		$data[$h . "_company"] = $params['companyname'];
		$data[$h . "_street"] = $params['address1'];
		$data[$h . "_postcode"] = $params['postcode'];
		$data[$h . "_city"] = $params['city'];
		$data[$h . "_country"] = $params['country'];
		$data[$h . "_telephone"] = $params['phonenumber'];
		$data[$h . "_telefax"] = "";
		$data[$h . "_email"] = $params['email'];
	}

	foreach(Array("tech", "zone") as $h){
		$data[$h . "_firstname"] = $params['Vorname'];
		$data[$h . "_lastname"] = $params['Nachname'];
		$data[$h . "_company"] = $params['Firma'];
		$data[$h . "_street"] = $params['Anschrift'];
		$data[$h . "_postcode"] = $params['Postleitzahl'];
		$data[$h . "_city"] = $params['Ort'];
		$data[$h . "_country"] = $params['Land'];
		$data[$h . "_telephone"] = $params['Telefon'];
		$data[$h . "_telefax"] = $params['Telefax'];
		$data[$h . "_email"] = $params['E-Mailadresse'];
	}

	$data['ip'] = sourceWAY_getIP($params);
	$data['privacy'] = $params['idprotection'] ? "1" : "0";

	for($i = 1; $i <= 5; $i++)
		if(!empty($params["ns" . $i]))
			$data["ns" . $i] = $params["ns" . $i];

	if(!empty($params['PowerDNS'])){
		$obj = sourceWAY_dns($params);
		if(!$obj) return Array("error" => "Verbindung zum DNS-Server fehlgeschlagen.");

		$domain = ($params["domainObj"]->getIdnSecondLevel() . $params["domainObj"]->getDotTopLevel());
		$ns = Array();
		for($i = 1; $i <= 5; $i++)
			if(!empty($params["ns" . $i]))
				array_push($ns, $params["ns" . $i]);

		$d = $obj->add($domain, $ns);
		$obj->def($params['IP-Adresse']);
	}

	if(!empty($params['PowerDNS'])){
		$obj = sourceWAY_dns($params);
		if(!$obj) return Array("error" => "Verbindung zum DNS-Server fehlgeschlagen.");

		$domain = ($params["domainObj"]->getIdnSecondLevel() . $params["domainObj"]->getDotTopLevel());
		$ns = Array();
		for($i = 1; $i <= 5; $i++)
			if(!empty($params["ns" . $i]))
				array_push($ns, $params["ns" . $i]);

		$d = $obj->add($domain, $ns);
		$obj->def($params['IP-Adresse']);
	}

	$ch = curl_init("https://sourceway.de/api/{$params['user']}/{$params['api_key']}/domain/register");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	curl_setopt($ch, CURLOPT_POST, true);
	curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data));
	$res = curl_exec($ch);
	curl_close($ch);

	$code = json_decode($res)->code;
	if($code != "100") return Array("error" => "Die Domain konnte nicht registriert werden: " . ($code == "813" ? ((String) json_decode($res)->data->detail) : json_decode($res)->message));
	return true;
}

function sourceWAY_TransferDomain($params) {
	$data = Array("domain" => $params['domainname']);

	foreach(Array("owner", "admin") as $h){
		$data[$h . "_firstname"] = $params['firstname'];
		$data[$h . "_lastname"] = $params['lastname'];
		$data[$h . "_company"] = $params['companyname'];
		$data[$h . "_street"] = $params['address1'];
		$data[$h . "_postcode"] = $params['postcode'];
		$data[$h . "_city"] = $params['city'];
		$data[$h . "_country"] = $params['country'];
		$data[$h . "_telephone"] = $params['phonenumber'];
		$data[$h . "_telefax"] = "";
		$data[$h . "_email"] = $params['email'];
	}

	foreach(Array("tech", "zone") as $h){
		$data[$h . "_firstname"] = $params['Vorname'];
		$data[$h . "_lastname"] = $params['Nachname'];
		$data[$h . "_company"] = $params['Firma'];
		$data[$h . "_street"] = $params['Anschrift'];
		$data[$h . "_postcode"] = $params['Postleitzahl'];
		$data[$h . "_city"] = $params['Ort'];
		$data[$h . "_country"] = $params['Land'];
		$data[$h . "_telephone"] = $params['Telefon'];
		$data[$h . "_telefax"] = $params['Telefax'];
		$data[$h . "_email"] = $params['E-Mailadresse'];
	}

	$data['password'] = $params['eppcode'];
	$data['privacy'] = $params['idprotection'] ? "1" : "0";
	$data['ip'] = sourceWAY_getIP($params);

	for($i = 1; $i <= 5; $i++)
		if(!empty($params["ns" . $i]))
			$data["ns" . $i] = $params["ns" . $i];

	$ch = curl_init("https://sourceway.de/api/{$params['user']}/{$params['api_key']}/domain/transfer");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	curl_setopt($ch, CURLOPT_POST, true);
	curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data));
	$res = curl_exec($ch);
	curl_close($ch);

	$code = json_decode($res)->code;
	if($code != "100") return Array("error" => "Die Domain konnte nicht transferiert werden: " . ($code == "814" ? ((String) json_decode($res)->data->detail) : json_decode($res)->message));
	return true;
}

function sourceWAY_GetContactDetails($params) {
	$res = file_get_contents("https://sourceway.de/api/{$params['user']}/{$params['api_key']}/domain/list?domain=" . urlencode($params['domainname']));
	$json = json_decode($res);

	if(!$res || !$json || $json->code != "100")
		return Array("error" => "Es ist ein technischer Fehler aufgetreten.");

	foreach($json->data as $d){
		if($d->domain != $params['domainname']) continue;

		$contacts = Array();
		foreach(Array("owner", "admin", "tech", "zone") as $h){
			if(empty($_SESSION['adminid']) && in_array($h, Array("tech", "zone")) && $params['cust_techzone'] != "on" && $params['cust_techzone'] != "yes") continue;
			$i = $d->$h;
			$contacts[ucfirst($h) . "-C"] = Array(
				"Vorname" => $i->firstname,
				"Nachname" => $i->lastname,
				"Firma" => $i->company,
				"Anschrift" => $i->street,
				"Postleitzahl" => $i->postcode,
				"Stadt" => $i->city,
				"Land" => $i->country,
				"Telefonnummer" => $i->telephone,
				"Faxnummer" => $i->telefax,
				"E-Mailadresse" => $i->email,
			);
		}

		return $contacts;
	}

	return Array("error" => "Die Domain ist bei sourceWAY.de nicht vorhanden.");
}

function sourceWAY_SaveContactDetails($params) {
	$res = file_get_contents("https://sourceway.de/api/{$params['user']}/{$params['api_key']}/domain/list?domain=" . urlencode($params['domainname']));
	$json = json_decode($res);

	if(!$res || !$json || $json->code != "100")
		return Array("error" => "Es ist ein technischer Fehler aufgetreten.");

	foreach($json->data as $d){
		if($d->domain != $params['domainname']) continue;

		$data = Array("domain" => $params['domainname']);

		foreach(Array("owner", "admin", "tech", "zone") as $h){
			$ha = ucfirst($h) . "-C";
			$info = $params['contactdetails'][$ha];
			if(!is_array($info)) return Array("error" => "Es wurden keine Daten f&uuml;r den $ha &uuml;bermittelt.");

			$data[$h . "_firstname"] = $info['Vorname'];
			$data[$h . "_lastname"] = $info['Nachname'];
			$data[$h . "_company"] = $info['Firma'];
			$data[$h . "_street"] = $info['Anschrift'];
			$data[$h . "_postcode"] = $info['Postleitzahl'];
			$data[$h . "_city"] = $info['Stadt'];
			$data[$h . "_country"] = $info['Land'];
			$data[$h . "_telephone"] = $info['Telefonnummer'];
			$data[$h . "_telefax"] = $info['Faxnummer'];
			$data[$h . "_email"] = $info['E-Mailadresse'];
		}

		for($i = 1; $i <= 5; $i++)
			if(!empty($d->ns[$i - 1]))
				$data["ns" . $i] = $d->ns[$i - 1];

		$data['transfer_lock'] = $d->transfer_lock;
		$data['auto_renew'] = $d->auto_renew;
		$data['ip'] = sourceWAY_getIP($params);
		$data['privacy'] = $params['idprotection'] ? "1" : "0";

		$ch = curl_init("https://sourceway.de/api/{$params['user']}/{$params['api_key']}/domain/modify");
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($ch, CURLOPT_POST, true);
		curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data));
		$res = curl_exec($ch);
		curl_close($ch);

		if(json_decode($res)->code != "100") return Array("error" => "Die Kontakt-Daten konnten nicht &uuml;bernommen werden.");
		return true;
	}

	return Array("error" => "Die Domain ist bei sourceWAY.de nicht vorhanden.");
}

function sourceWAY_GetEPPCode($params) {
	$res = file_get_contents("https://sourceway.de/api/{$params['user']}/{$params['api_key']}/domain/password?domain=" . urlencode($params['domainname']));
	$json = json_decode($res);

	if(!$res || !$json || $json->code != "100")
		return Array("error" => "Es ist ein Fehler aufgetreten. Ist die Transfer-Sperre eventuell aktiv?");

	return Array("eppcode" => $json->data->code);
}

function sourceWAY_GetRegistrarLock($params) {
	$res = file_get_contents("https://sourceway.de/api/{$params['user']}/{$params['api_key']}/domain/list?domain=" . urlencode($params['domainname']));
	$json = json_decode($res);

	if(!$res || !$json || $json->code != "100")
		return Array("error" => "Es ist ein technischer Fehler aufgetreten.");

	foreach($json->data as $d){
		if($d->domain != $params['domainname']) continue;
		return $d->transfer_lock == "1" ? "locked" : "";
	}

	return Array("error" => "Die Domain wurde nicht gefunden.");
}

function sourceWAY_IDProtectToggle($params) {
	$res = file_get_contents("https://sourceway.de/api/{$params['user']}/{$params['api_key']}/domain/list?domain=" . urlencode($params['domainname']));
	$json = json_decode($res);

	if(!$res || !$json || $json->code != "100")
		return Array("error" => "Es ist ein technischer Fehler aufgetreten.");

	foreach($json->data as $d){
		if($d->domain != $params['domainname']) continue;

		$data = Array("domain" => $params['domainname']);

		foreach(Array("owner", "admin", "tech", "zone") as $h)
			foreach($d->$h as $k => $v)
				$data[$h . "_" . $k] = $v;

		for($i = 1; $i <= 5; $i++)
			if(!empty($d->ns[$i - 1]))
				$data["ns" . $i] = $d->ns[$i - 1];

		$data['transfer_lock'] = $d->transfer_lock;
		$data['auto_renew'] = $d->auto_renew;
		$data['ip'] = sourceWAY_getIP($params);
		$data['privacy'] = $params['idprotection'] ? "1" : "0";

		$ch = curl_init("https://sourceway.de/api/{$params['user']}/{$params['api_key']}/domain/modify");
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($ch, CURLOPT_POST, true);
		curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data));
		$res = curl_exec($ch);
		curl_close($ch);

		if(json_decode($res)->code != "100") return Array("error" => "Der Privacy-Status konnte nicht &uuml;bernommen werden.");
		return true;
	}

	return Array("error" => "Die Domain ist bei sourceWAY.de nicht vorhanden.");
}

function sourceWAY_SaveRegistrarLock($params) {
	$res = file_get_contents("https://sourceway.de/api/{$params['user']}/{$params['api_key']}/domain/list?domain=" . urlencode($params['domainname']));
	$json = json_decode($res);

	if(!$res || !$json || $json->code != "100")
		return Array("error" => "Es ist ein technischer Fehler aufgetreten.");

	foreach($json->data as $d){
		if($d->domain != $params['domainname']) continue;

		$data = Array("domain" => $params['domainname']);

		foreach(Array("owner", "admin", "tech", "zone") as $h)
			foreach($d->$h as $k => $v)
				$data[$h . "_" . $k] = $v;

		for($i = 1; $i <= 5; $i++)
			if(!empty($d->ns[$i - 1]))
				$data["ns" . $i] = $d->ns[$i - 1];

		$data['transfer_lock'] = $params['lockenabled'] == "locked" ? 1 : 0;
		$data['auto_renew'] = $d->auto_renew;
		$data['ip'] = sourceWAY_getIP($params);
		$data['privacy'] = $params['idprotection'] ? "1" : "0";

		$ch = curl_init("https://sourceway.de/api/{$params['user']}/{$params['api_key']}/domain/modify");
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($ch, CURLOPT_POST, true);
		curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data));
		$res = curl_exec($ch);
		curl_close($ch);

		if(json_decode($res)->code != "100") return Array("error" => "Der Lock-Status konnte nicht &uuml;bernommen werden.");
		return true;
	}

	return Array("error" => "Die Domain ist bei sourceWAY.de nicht vorhanden.");
}

function sourceWAY_RequestDelete($params) {
	$res = file_get_contents("https://sourceway.de/api/{$params['user']}/{$params['api_key']}/domain/delete?domain=" . urlencode($params['domain']) . "&type=0");
	$json = json_decode($res);

	if(!$res || !$json || $json->code != "100")
		return Array("error" => "Es ist ein technischer Fehler aufgetreten.");

	return true;
}

function sourceWAY_TransferSync($params) {
	$res = file_get_contents("https://sourceway.de/api/{$params['user']}/{$params['api_key']}/domain/list?domain=" . urlencode($params['domain']));
	$json = json_decode($res);

	if(!$res || !$json || $json->code != "100")
		return Array("error" => "Es ist ein technischer Fehler aufgetreten.");

	foreach($json->data as $d){
		if($d->domain != $params['domain']) continue;
		if($d->status == "KK_WAITING") return Array("completed" => false);
		if($d->status == "KK_OK") return Array("completed" => true, "expirydate" => $d->expiration);
	}

	return Array("failed" => true);
}

function sourceWAY_Sync($params) {
	$res = file_get_contents("https://sourceway.de/api/{$params['user']}/{$params['api_key']}/domain/list?domain=" . urlencode($params['domain']));
	$json = json_decode($res);

	if(!$res || !$json || $json->code != "100")
		return Array("error" => "Es ist ein technischer Fehler aufgetreten.");

	foreach($json->data as $d){
		if($d->domain != $params['domain']) continue;

		$auto_renew = 1;
		$dnr = Capsule::table("tbldomains")->where("id", $params['domainid'])->get();
		if(count($dnr) == 1){
			$dnr = $dnr[0]->donotrenew;
			if($dnr == 1){
				$auto_renew = 0;
			} else {
				$auto_renew = 1;
			}
		}

		$data = Array("domain" => $params['domainname']);

		foreach(Array("owner", "admin", "tech", "zone") as $h)
			foreach($d->$h as $k => $v)
				$data[$h . "_" . $k] = $v;

		for($i = 1; $i <= 5; $i++)
			if(!empty($d->ns[$i - 1]))
				$data["ns" . $i] = $d->ns[$i - 1];

		$data['transfer_lock'] = $params['lockenabled'] == "locked" ? 1 : 0;
		$data['auto_renew'] = $auto_renew;
		$data['ip'] = sourceWAY_getIP($params);
		$data['privacy'] = $params['idprotection'] ? "1" : "0";

		$ch = curl_init("https://sourceway.de/api/{$params['user']}/{$params['api_key']}/domain/modify");
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($ch, CURLOPT_POST, true);
		curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data));
		curl_exec($ch);
		curl_close($ch);

		return Array("active" => in_array($d->status, Array("REG_OK", "KK_OK")), "expired" => false, "expirydate" => $d->expiration);
	}

	return Array("active" => false, "expired" => true);
}

function sourceWAY_TransitConnect($params) {
	$res = file_get_contents("https://sourceway.de/api/{$params['user']}/{$params['api_key']}/domain/delete?domain=" . urlencode($params['domain']) . "&type=1");
	$json = json_decode($res);

	if(!$res || !$json || $json->code != "100")
		return Array("error" => "Es ist ein technischer Fehler aufgetreten.");

	return true;
}

function sourceWAY_TransitDeconnect($params) {
	$res = file_get_contents("https://sourceway.de/api/{$params['user']}/{$params['api_key']}/domain/delete?domain=" . urlencode($params['domain']) . "&type=2");
	$json = json_decode($res);

	if(!$res || !$json || $json->code != "100")
		return Array("error" => "Es ist ein technischer Fehler aufgetreten.");

	return true;
}

function sourceWAY_AdminCustomButtonArray($params) {
	return Array(
		"Transit (konnektiert)" => "TransitConnect",
		"Transit (dekonnektiert)" => "TransitDeconnect",
	);
}