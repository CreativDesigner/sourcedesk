<?php

// Give parameters product, name and email as GET

require_once dirname(__FILE__) . "/config.php";
require_once dirname(__FILE__) . "/../Reseller.class.php";

$reseller = new ResellerAPI(URL, UID, KEY);
$result = $reseller->addLicense($_GET['product'], $_GET['name'], $_GET['email']);

if(!$result) die("Adding License failed!");
echo "License was added! ID: $result";

?>