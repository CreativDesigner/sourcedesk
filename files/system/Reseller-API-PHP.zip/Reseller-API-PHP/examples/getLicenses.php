<?php

require_once dirname(__FILE__) . "/config.php";
require_once dirname(__FILE__) . "/../Reseller.class.php";

$reseller = new ResellerAPI(URL, UID, KEY);
$licenses = $reseller->getLicenses();

?>
<table>
	<tr>
		<th>Product ID</th>
		<th>Customer</th>
		<th>Email</th>
	</tr>
<?php

foreach($licenses as $license){
?>

	<tr>
		<td><?=$license['product']; ?></td>
		<td><?=$license['name']; ?></td>
		<td><?=$license['email']; ?></td>
	</tr>
	
<?php 
}
?>
</table>