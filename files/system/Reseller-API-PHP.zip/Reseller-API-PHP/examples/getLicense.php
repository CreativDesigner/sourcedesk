<?php

// Pass id via GET

require_once dirname(__FILE__) . "/config.php";
require_once dirname(__FILE__) . "/../Reseller.class.php";

$reseller = new ResellerAPI(URL, UID, KEY);
$license = $reseller->getLicense($_GET['id']);

if(count($license) == 0) die("License not found!");

?>
<table>
	<tr>
		<th>Product ID</th>
		<th>Customer</th>
		<th>Email</th>
	</tr>
	<tr>
		<td><?=$license['product']; ?></td>
		<td><?=$license['name']; ?></td>
		<td><?=$license['email']; ?></td>
	</tr>
</table>