<?php

define('SHOP', "https://sourceway.de");
define('UID', 1234);
define('KEY', '3846f792b45a6e7512426c7b4d3f6965');

?>