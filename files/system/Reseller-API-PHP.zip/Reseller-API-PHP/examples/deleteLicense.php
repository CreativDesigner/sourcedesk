<?php

// Pass id via GET

require_once dirname(__FILE__) . "/config.php";
require_once dirname(__FILE__) . "/../Reseller.class.php";

$reseller = new ResellerAPI(URL, UID, KEY);
$result = $reseller->deleteLicense($_GET['id']);

if(!$result) die("License not found!");
echo "License was deleted!";

?>