<?php

// Pass id, name, email via GET

require_once dirname(__FILE__) . "/config.php";
require_once dirname(__FILE__) . "/../Reseller.class.php";

$reseller = new ResellerAPI(URL, UID, KEY);
$result = $reseller->updateLicense($_GET['id'], $_GET['name'], $_GET['email']);

if(!$result) die("License could not be updated!");
echo "License updated!";

?>