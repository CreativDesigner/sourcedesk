<?php

class ResellerAPI {

	private $url = null;
	private $usr = null;
	private $pwd = null;
	private $par = null;
	
	// Constructor
	// Requires: API URI, User ID, API key
	
	public function __construct($url, $usr, $pwd){
	
		$this->par = "?";
		$this->url = $url . "/reseller_api";		
		$this->usr = (int) $usr;
		$this->pwd = $pwd;
	
	}
	
	// Method gives back all licenses
	// Returns array with license arrays with elements product (ID), name (customer name), email (customer email), language (customer language)
	
	public function getLicenses() {
	
		$arr = Array("method" => "getLicenses");
		array_walk($arr, Array($this, 'aCode'));
		return (array) json_decode($this->doRequest($arr));
	
	}
	
	// Gives information about a particular license
	// Requires license ID
	// Returns false or array with elements product (ID), name (customer name), email (customer email), language (customer language)
	
	public function getLicense($id) {
	
		$arr = Array("method" => "getLicenses", "id" => $id);
		array_walk($arr, Array($this, 'aCode'));
		$res = $this->doRequest($arr);
		return !$res ? false : (array) json_decode($this->doRequest($arr));
	
	}
	
	// Updates the customer information for a license
	// Requires license ID
	// Optional parameters: name, email, language (no change if left blank)
	// Returns true or false
	
	public function updateLicense($id, $name = null, $email = null, $language = null) {
	
		$arr = Array("method" => "updateLicense", "id" => $id);

		$additional = Array("name", "email", "language");
		foreach ($additional as $v) 
			if($$v != null)
				$arr[$v] = $$v;

		array_walk($arr, Array($this, 'aCode'));
		return (bool) $this->doRequest($arr);
	
	}
	
	// Deletes a license
	// Requires license ID
	// Returns true or false
	
	public function deleteLicense($id) {
		
		$arr = Array("method" => "deleteLicense" , "id" => $id);
		array_walk($arr, Array($this, 'aCode'));
		return (bool) $this->doRequest($arr);
	
	}
	
	// Adds a new license
	// Requires product ID, customer name, customer email
	// Optional parameter language (for example english) - if left blank, default is used
	// Returns false or the new license ID
	
	public function addLicense($product, $name, $email, $language = null) {
	
		$arr = Array("method" => "addLicense", "product" => $product, "name" => $name, "email" => $email);
		if($language != null) $arr["language"] = $language;
		array_walk($arr, Array($this, 'aCode'));
		
		$erg = $this->doRequest($arr);
		return !$erg ? false : (int) $erg;
	
	}
	
	private function doRequest($par) {
	
		$append = $this->par . "usr=" . $this->usr . "&pwd=" . $this->pwd;
		foreach($par as $k => $v)
			$append .= "&" . $k . "=" . $v;
		
		if(in_array('curl', get_loaded_extensions())){
			$ch = curl_init();
			curl_setopt($ch, CURLOPT_URL, $this->url . $append);
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
			curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 5);
			$data = curl_exec($ch);
			curl_close($ch);
			
			if($data === false)
				return file_get_contents($this->url . $append);
			
			return $data;
		} else {
			return file_get_contents($this->url . $append);
		}
	
	}
	
	private function aCode(&$v, $k){
		$v = urlencode($v);
	}

}

?>